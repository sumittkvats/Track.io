package io.github.appsrc.trackio

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.Polyline
import com.google.android.gms.maps.model.PolylineOptions
import com.google.firebase.database.*
import io.github.appsrc.trackio.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity() {
    private  lateinit var  binding: ActivityMainBinding
    private lateinit var database: FirebaseDatabase
    private lateinit var ref: DatabaseReference
    private lateinit var crref: DatabaseReference
    private val MAX_CURRENT = 16F
    private val RESIDUE = 0.00F
    private var current = 0.0F
    private val voltage = 0.0F
    private lateinit var googleMap: SupportMapFragment
    override fun onCreate(savedInstanceState: Bundle?) {
        binding = ActivityMainBinding.inflate(layoutInflater)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        database = FirebaseDatabase.getInstance("https://trackio-rg-default-rtdb.asia-southeast1.firebasedatabase.app")
        ref = database.getReference("test/current")
        ref.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                var value = snapshot.getValue(Float::class.java)
                if (value != null) {
                    value*=2
                    value += RESIDUE
                    binding.progressBar.progress = ((value/2)/MAX_CURRENT*100).toInt()
                    binding.textView.text = "$value Amps"
                    var watt = value*current
                    binding.watts.text = "$watt Watts"
                    //TODO max current is 20A, current value +0.67A
                }

            }
            override fun onCancelled(error: DatabaseError) {
                binding.progressBar.progress = 0
            }

        })

        crref = database.getReference("test/volt")
        crref.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                var value = snapshot.getValue(Float::class.java)
                if (value != null) {
//                    value += RESIDUE
//                    binding.progressBar.progress = ((value/2)/MAX_CURRENT*100).toInt()
                    binding.volts.text = "$value Volts"
                    current = value.toFloat()
                    //TODO max current is 20A, current value +0.67A
                }

            }
            override fun onCancelled(error: DatabaseError) {
                binding.progressBar.progress = 0
            }

        })
        Glide.with(this).load(R.drawable.map).centerCrop().into(binding.mapView)
        binding.mapView.setOnClickListener(View.OnClickListener {
            val gmmIntentUri =
                Uri.parse("https://www.google.com/maps/search/?api=1&query=28.6781389,77.2604057")
            val browserIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri)
            startActivity(browserIntent)
        })

//        googleMap = supportFragmentManager.findFragmentById(R.id.mapView) as SupportMapFragment
//        googleMap.getMapAsync(this)
    }

//    override fun onMapReady(p0: GoogleMap) {
////        p0.addPolyline(PolylineOptions()
////            .clickable(true)
////            .add(
////                LatLng(	28.5018	,	77.32261	),
////                LatLng(	28.5019	,	77.32259	),
////                LatLng(	28.50182	,	77.32259	),
////                LatLng(	28.50183	,	77.32256	),
////                LatLng(	28.50187	,	77.32255	),
////                LatLng(	28.50186	,	77.32247	),
////                LatLng(	28.50172	,	77.32253	),
////                LatLng(	28.50167	,	77.32256	),
////                LatLng(	28.50183	,	77.32268	),
////                LatLng(	28.50185	,	77.32253	),
////                LatLng(	28.50179	,	77.32253	),
////                LatLng(	28.50167	,	77.3225	),
////                LatLng(	28.50165	,	77.32245	),
////                LatLng(	28.50179	,	77.32264	),
////                LatLng(	28.50178	,	77.32257	),
////                LatLng(	28.50177	,	77.32261	),
////                LatLng(	28.50182	,	77.32262	),
////                LatLng(	28.50191	,	77.32269	),
////                LatLng(	28.50178	,	77.32253	),
////                LatLng(	28.50176	,	77.32259	),
////                LatLng(	28.50181	,	77.32275	),
////                LatLng(	28.50174	,	77.32267	),
////                LatLng(	28.5018	,	77.32259	),
////                LatLng(	28.50185	,	77.32258	),
////                LatLng(	28.50176	,	77.3225	),
////                LatLng(	28.50172	,	77.32259	),
////                LatLng(	28.50173	,	77.32259	),
////                LatLng(	28.50177	,	77.32248	),
////                LatLng(	28.50172	,	77.32259	),
////                LatLng(	28.50177	,	77.32261	),
////                LatLng(	28.50182	,	77.32265	),
////                LatLng(	28.50182	,	77.32259	),
////                LatLng(	28.50185	,	77.32267	),
////                LatLng(	28.50184	,	77.32274	),
////                LatLng(	28.50182	,	77.32255	),
////                LatLng(	28.50185	,	77.3226	),
////                LatLng(	28.50185	,	77.32266	),
////                LatLng(	28.50188	,	77.32282	),
////                LatLng(	28.50184	,	77.32255	),
////                LatLng(	28.50181	,	77.32259	),
////                LatLng(	28.50178	,	77.32269	),
////                LatLng(	28.50181	,	77.32261	),
////                LatLng(	28.50179	,	77.32255	),
////                LatLng(	28.50179	,	77.32258	),
////                LatLng(	28.50185	,	77.32256	),
////                LatLng(	28.50177	,	77.32253	),
////                LatLng(	28.50179	,	77.32266	),
////                LatLng(	28.50182	,	77.32257	),
////                LatLng(	28.5017	,	77.32256	),
////                LatLng(	28.50161	,	77.32263	),
////                LatLng(	28.50163	,	77.32254	),
////                LatLng(	28.50174	,	77.32262	),
////                LatLng(	28.50171	,	77.32248	),
////                LatLng(	28.50175	,	77.32257	),
////                LatLng(	28.5018	,	77.3226	),
////                LatLng(	28.50186	,	77.32257	),
////                LatLng(	28.5018	,	77.32265	),
////                LatLng(	28.50183	,	77.32262	),
////                LatLng(	28.50175	,	77.32261	),
////                LatLng(	28.50175	,	77.32248	),
////                LatLng(	28.50177	,	77.32258	),
////                LatLng(	28.50173	,	77.32256	),
////                LatLng(	28.50175	,	77.32259	),
////                LatLng(	28.50183	,	77.32265	),
////                LatLng(	28.50179	,	77.32262	),
////                LatLng(	28.50178	,	77.32256	),
////                LatLng(	28.50181	,	77.32257	),
////                LatLng(	28.50181	,	77.32262	),
////                LatLng(	28.50182	,	77.32262	),
////                LatLng(	28.50179	,	77.32264	),
////                LatLng(	28.50184	,	77.32262	),
////                LatLng(	28.50178	,	77.32259	),
////                LatLng(	28.50182	,	77.32255	),
////                LatLng(	28.5018	,	77.32259	),
////                LatLng(	28.50178	,	77.32262	),
////                LatLng(	28.50184	,	77.32266	),
////                LatLng(	28.50179	,	77.32267	),
////                LatLng(	28.50178	,	77.32267	),
////                LatLng(	28.50171	,	77.32251	),
////                LatLng(	28.50177	,	77.32259	),
////                LatLng(	28.50176	,	77.3225	),
////                LatLng(	28.50185	,	77.3226	),
////                LatLng(	28.50177	,	77.32257	),
////                LatLng(	28.50176	,	77.32254	),
////                LatLng(	28.50179	,	77.32251	),
////                LatLng(	28.50176	,	77.32256	),
////                LatLng(	28.50176	,	77.32267	)
////            ).width(5F).color(Color.RED))
//        p0.moveCamera(CameraUpdateFactory.newLatLngZoom(LatLng(	28.50176	,	77.32267	), 12f))
//
//
//
//    }
}