package io.github.appsrc.trackio

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.navigation.ui.AppBarConfiguration
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import io.github.appsrc.trackio.databinding.ActivityDevicesBinding
import io.github.appsrc.trackio.models.DeviceAdapter


class DevicesActivity : AppCompatActivity(),OnMapReadyCallback {

    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var binding: ActivityDevicesBinding
    private lateinit var googleMap: SupportMapFragment

    override fun onCreate(savedInstanceState: Bundle?) {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        super.onCreate(savedInstanceState)
        binding = ActivityDevicesBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.listView.adapter = DeviceAdapter(arrayListOf("RG-Bot", "DL2CK****", "DL42Z****", "Device 4"))
        binding.listView.layoutManager = androidx.recyclerview.widget.LinearLayoutManager(this)
        googleMap=supportFragmentManager.findFragmentById(R.id.map) as SupportMapFragment
        googleMap.getMapAsync(this)
    }

    override fun onMapReady(p0: GoogleMap) {
        var sydney = LatLng(28.677242, 77.388959)
        p0.addMarker(
            MarkerOptions()
                .position(sydney)
                .title("DL42Z****")
        )
        sydney = LatLng(28.677771, 77.260627)
        p0.addMarker(
            MarkerOptions()
                .position(sydney)
                .title("RG-Bot")
        )
        p0.moveCamera((CameraUpdateFactory.newLatLngZoom(sydney, 12.0f)))
        p0.addMarker(
            MarkerOptions()
                .position(LatLng(28.587662, 77.388959))
                .title("DL2CK****")
        )
    }
}