package io.github.appsrc.trackio

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import com.bumptech.glide.Glide
import io.github.appsrc.trackio.databinding.ActivitySplashScreenBinding

class SplashScreen : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        val binding = ActivitySplashScreenBinding.inflate(layoutInflater)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        var glide = Glide.with(this)
        glide.load(R.drawable.car).into(binding.logoIv)

        Handler(Looper.getMainLooper()).postDelayed({
            startActivity(Intent(this, DevicesActivity::class.java))
            finish()
        }, 5500)



    }
}