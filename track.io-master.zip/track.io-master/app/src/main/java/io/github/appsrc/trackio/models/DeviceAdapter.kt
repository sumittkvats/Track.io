package io.github.appsrc.trackio.models

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import io.github.appsrc.trackio.R

class DeviceAdapter (private val mList: List<String>) : RecyclerView.Adapter<DeviceAdapter.ViewHolder>() {

    // create new views
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        // inflates the card_view_design view
        // that is used to hold list item
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_device, parent, false)

        return ViewHolder(view)
    }

    // binds the list items to a view
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        holder.textView.text = mList[position]
        holder.btn.setOnClickListener(
            View.OnClickListener {
                holder.btn.context.startActivity(
                    android.content.Intent(holder.btn.context, io.github.appsrc.trackio.MainActivity::class.java)
                )
            }
        )
    }

    // return the number of the items in the list
    override fun getItemCount(): Int {
        return mList.size
    }

    // Holds the views for adding it to image and text
    class ViewHolder(ItemView: View) : RecyclerView.ViewHolder(ItemView) {
        val textView: TextView = itemView.findViewById(R.id.vehicleName)
        val btn: Button = itemView.findViewById(R.id.detailsBtn)
    }
}